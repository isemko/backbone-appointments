var app = app || {};
/*function AppView() {

 this.showView(view) {
 if (this.currentView) {
 this.currentView.close();
 }

 this.currentView = view;
 this.currentView.render();

 $("#mainContent").html(this.currentView.el);
 }

 }
 */

app.MyRouter = Backbone.Router.extend({
	navView : new app.MainNav(),
	routes : {
		"" : "index",
		"appointments/:id" : "showAppointment",
		"edit" : "editMain",
		"add" : "addApp"

	},
	initialize : function(options) {

		//this.collection.on('reset', this.render, this);
	},

	index : function() {
		this.releaseNav();
		this.navView = new app.MainNav();
		var homeView = new app.AppointmentListView();
		homeView.viewFetch();
	},
	releaseNav : function() {
		$(this.navView).empty
		this.navView.undelegateEvents();
		this.navView.unbind();
	},
	showAppointment : function(id) {
		this.navView.showEdit('appointment indy view');
	},
	editMain : function() {
		this.releaseNav();
		this.navView = new app.EditNav();
		$('.del, .app-link').show();
	},
	addApp : function() {
		this.releaseNav();
		var navView = new app.AddNav();

	}
});
$(function() {

	appMain = new app.MyRouter();
	Backbone.history.start({
		pushState : true
	});
});
